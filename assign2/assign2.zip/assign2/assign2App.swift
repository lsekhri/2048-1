//
//  assign2App.swift
//  assign2
//
//  Created by Laksh Sekhri on 10/3/21.
//

import SwiftUI

@main
struct assign2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
